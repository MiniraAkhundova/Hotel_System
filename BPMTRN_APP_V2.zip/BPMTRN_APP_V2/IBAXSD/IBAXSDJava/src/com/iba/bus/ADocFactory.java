package com.iba.bus;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ADocFactory {
	
	/**
	 * This function unzip-s input file and creates files in given destDir
	 * 
	 * @param zipFilePath - full path to file
	 * @param destDir - destination directory for unzipped files
	 * 
	 * @return - number of files unzipped
	 */
	public static Integer unzip(String zipFilePath, String destDir) {
        File dir = new File(destDir);
        if(!dir.exists()) dir.mkdirs();
        FileInputStream fis;
        List<String> fileSaveResult = new ArrayList<String>();
        byte[] buffer = new byte[1024];
        try {
            fis = new FileInputStream(zipFilePath);
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while(ze != null){
                String fileName = ze.getName();
                if(fileName.endsWith("pdf")){
                File newFile = new File(destDir + File.separator + fileName);
                fileSaveResult.add(newFile.getAbsolutePath());
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
                }
                fos.close();
                zis.closeEntry();
                }
                ze = zis.getNextEntry();
                
            }
            zis.close();
            fis.close();
            new File(zipFilePath).delete();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileSaveResult.size();
    }
}
