package com.iba.bpm;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;










import com.ibar.bus.IbaReplaceNumber;
import com.ibm.broker.config.proxy.*;


public class CommonRoutines {

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
//	public static java.lang.Object sampleTransform() {
	public static String generateUUIDBasedCorrelationID() {
		return String.format("%048x",Math.abs(UUID.randomUUID().hashCode()));
	}
	
	public static String getConfServicePropertyValue(String csName, String propertyName){
		String propertyValue = null;
		try {
			BrokerProxy br = BrokerProxy.getLocalInstance();
			
			while(!br.hasBeenPopulatedByBroker()) { 
				Thread.sleep(100);
			}  
			
			ConfigurableService cs = br.getConfigurableService("UserDefined", csName);
			propertyValue = cs.getProperties().getProperty(propertyName);
			br.disconnect();
			
		} catch (ConfigManagerProxyLoggedException e ) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ConfigManagerProxyPropertyNotInitializedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return propertyValue;
		
	}
	
	public static String getIbarNumber(String number){
		IbaReplaceNumber rn =  new IbaReplaceNumber();
//		String a ;

		if (number.toUpperCase().startsWith("N"))
		{
			return number.substring(1);
		}
		
		return rn.getReplaceNumber(number);
	}
	
	
	public static Boolean isOperatorDisallowed(String wsName, String operator)
	{
		String wsDisallowedOperators = getConfServicePropertyValue("Restrictions", wsName.toUpperCase() + "DisallowedOperators");
		return operator.matches(wsDisallowedOperators); 
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println(getIbarNumber("67621332173118659"));
	}
	
	
}
