package com.iba.lib;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Date;
import java.util.UUID;

public class RefAndIdRoutines {

	public static java.lang.String dateTo_yymm_format(java.lang.Object cardExpiryDate) 
	{
		String cardExpireDate_yymm;
		cardExpireDate_yymm = String.format("%1$ty%1$tm", (Date)cardExpiryDate );
		return cardExpireDate_yymm;
	}
	
	public static String generateUUIDBasedHash() {
		String hashCode = ""+Math.abs(UUID.randomUUID().hashCode());
		return hashCode.substring(0, 6);
	}
	public static String generateHashFromString( String line ) {
		return ""+line;
	}
	
	public static String generateCryptedHash(String value, String algorythm) {
		String result = null;
		if(algorythm == null || algorythm.length() == 0){
			algorythm = "SHA-256";
		}
		try{
			MessageDigest md = MessageDigest.getInstance(algorythm);	       
	        md.update(value.getBytes("UTF-8")); 
	        byte[] digest = md.digest();
	        result = String.format("%064x", new java.math.BigInteger(1, digest));
		} catch(Exception e){			
		}       
       return result;   
	}
	
	
	public static String generateRandomCode(java.lang.Long len) 
	{
        String LOWER = "abcdefghijklmnopqrstuvwxyz";
        String UPPER = LOWER.toUpperCase();
        String DIGITS = "0123456789";
        String PUNCTUATION = "!@#$%&";
        SecureRandom rnd = new SecureRandom();
        String ALL_SYMBOL =UPPER + DIGITS ;
       StringBuilder sb = new StringBuilder(len.intValue());
       sb.append(UPPER.charAt(rnd.nextInt(UPPER.length())));
       for (int i = 1; i < len; i++) {
           sb.append(ALL_SYMBOL.charAt(rnd.nextInt(ALL_SYMBOL.length())));
       }
       return sb.toString();
   }
}
