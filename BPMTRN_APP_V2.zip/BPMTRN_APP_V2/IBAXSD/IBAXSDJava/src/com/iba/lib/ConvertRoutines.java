package com.iba.lib;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class ConvertRoutines {

	/*************************************************************
	 * This function converts string representation of time in millis to 
	 * xsd date format
	 * *************************************************************/
	public static String convertFromStringMillisToDate(String strMillis)
	{	
		Long tmpLong = Long.valueOf(strMillis);
		Date tmpDate = new Date(tmpLong.longValue());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		String strXsdDate = df.format(tmpDate);  
		
		return strXsdDate;
	}
	
	public static String convertFromStringMillisToDateWithTimeZone(String strMillis, String timeZone)
	{	
		Long tmpLong = Long.valueOf(strMillis);
		Calendar original = Calendar.getInstance();

		TimeZone my = original.getTimeZone();
		original.setTimeInMillis(tmpLong.longValue());
		
	/*	if (timeZone == "" || timeZone == null)
			timeZone = "GMT";
		
		//String strXsdDate = df.format(original.get);
		//String strXsdDate = String.format("%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS %1$tZ %1$tz", original);
		//System.out.println("Before time zone " + strXsdDate);

		if (timeZone == "AZST")
			original.setTimeZone(my);
		else */
			original.setTimeZone(TimeZone.getTimeZone(timeZone));
		
		// original.setTimeZone(TimeZone.getTimeZone("GMT+4"));
		
		String strXsdDate = String.format("%1$tY-%1$tm-%1$td", original);
		System.out.println("After time zone " + strXsdDate);
		
		
		return strXsdDate;

	}
	
	public static void main(String[] args) 
	{
		ConvertRoutines.convertFromStringMillisToDateWithTimeZone("1581364800000","UTC");
		ConvertRoutines.convertFromStringMillisToDateWithTimeZone("1581364800000","GMT+4");
		ConvertRoutines.convertFromStringMillisToDateWithTimeZone("1581364800000","AZST");
	}

	
}
