package com.iba.mail;
import javax.mail.*;


public class EmailRoutines {
	
	  public static String takePartOfMIME(Part p) throws Exception {
		  
		  String text = null;
	    
		  if (p.isMimeType("text/plain")) {
			  return (String) p.getContent();   
		  } 
		  else if (p.isMimeType("multipart/*")) {
			  Multipart mp = (Multipart) p.getContent();
			  int count = mp.getCount();
		      for (int i = 0; i < count; i++){
		          text = takePartOfMIME(mp.getBodyPart(i));
		          if (text!=null) return text;
		        }
		  } 
          else {
              Object o = p.getContent();
              if (o instanceof String) 
            	  return (String) o; 
          }
		  return text;
	 }
}
