package gnl;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;



public class getAttrForINV {

public static String getNumberByCardNumberForMPSendOTP(String uID) {
		
		LdapUtils lb = new LdapUtils();
		
		DirContext dirContextBB = null; 
		String phoneNumber = "" ;
        String user = "CN=backbase,OU=Admin users,DC=ibanking,DC=int";
        String pass = "Pass4BBase";
        String url = "ldap://10.128.38.13:389";
		String searchParam = "(&(objectCategory=user)(uid=" + uID + "))" ;
		String searchContext = "DC=ibanking,DC=int";
		SearchControls controls = new SearchControls();
        controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        NamingEnumeration answer= null;
		
        
        
try {
        	
		if	(dirContextBB == null)
		{	
			dirContextBB = lb.getLdapContext(user, pass, url, dirContextBB);
		}
			
			
			answer = dirContextBB.search( searchContext, searchParam, controls);
			
			 while (answer.hasMoreElements()) {
                    Attributes attrs = ((SearchResult) answer.next()).getAttributes(); 
	              
                    phoneNumber =  attrs.get("telephoneNumber").toString();
                    
                    phoneNumber = phoneNumber.replace("telephoneNumber:" , "").trim();
	             
	            }
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();

			
		}finally{
			if(dirContextBB!= null){
				lb.closeLdapContext(dirContextBB);
			}

		}
        
		
		return phoneNumber ; 
	}
	
	

	
	
}
