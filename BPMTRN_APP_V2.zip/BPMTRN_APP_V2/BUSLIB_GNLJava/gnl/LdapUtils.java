package gnl;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import com.iba.bpm.CommonRoutines;


public class LdapUtils 
{
	private DirContext dirContext = null;
	
	/******************************************************************
	 * This function returns connection to LDAP server. 
	 * Connection details are taken from IBM IB's configurable services
	 * 
	 * @return DirContext
	 *****************************************************************/
	public DirContext getLdapContext(String user, String pass, String url){

		
			try
			{
	            Hashtable<String, String> env = new Hashtable<String, String>();
	            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
	            env.put(Context.SECURITY_AUTHENTICATION, "simple");
	            env.put(Context.SECURITY_PRINCIPAL, "sys2");
	            env.put(Context.SECURITY_CREDENTIALS, pass);
	            System.out.print("");
	            env.put(Context.PROVIDER_URL, url);
	            
	            dirContext = new InitialDirContext(env);
	        }
			catch(NamingException nex)
			{
	            nex.printStackTrace();
	        }
		
        return dirContext;
    }
	
	
	
	public DirContext getLdapContext(String user, String pass, String url, DirContext dirContextBB){

		
		if (dirContextBB == null)
		{
			try
			{
                     
                            
	            Hashtable<String, String> env = new Hashtable<String, String>();
	            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
	            env.put(Context.SECURITY_AUTHENTICATION, "simple");
	            env.put(Context.SECURITY_PRINCIPAL, user);
	            env.put(Context.SECURITY_CREDENTIALS, pass);
	            env.put(Context.PROVIDER_URL, url);
	            env.put("com.sun.jndi.ldap.connect.pool", "true");
	            //env.put("connection.pool.max.size", "40");
	            env.put("com.sun.jndi.ldap.connect.timeout", "10000");
	            env.put("com.sun.jndi.ldap.read.timeout", "1000");
	            
	            dirContextBB = new InitialDirContext(env);
	        }
			catch(NamingException nex)
			{
                            
                            System.out.println("error + " + nex.getExplanation());
                            
	            nex.printStackTrace();
	            return null;
	        }
		}
	
    return dirContextBB;
}
	
	
	/******************************************************************
	 * 
	 * Closes Ldap connection.
	 *****************************************************************/
	public void closeLdapContext(DirContext dirContext)
	{
		try 
		{
			if (dirContext != null)
				dirContext.close();
		} 
		catch (NamingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e)
		{
			
		}
	}
	
	
	
	
	/******************************************************************
	 * 
	 * Retrives a list of users and their attributes of specified branchCode 
	 * and stores that retrived data in a form of the list of attributes (attr)
	 * 
	 * @param branchCode
	 *****************************************************************/
	private NamingEnumeration searchLdap(String searchString)
	{
		NamingEnumeration searchResult;
		
		SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        
		try 
		{
			searchResult = dirContext.search(CommonRoutines.getConfServicePropertyValue("LDAP", "searchContext"),
											 searchString, 
											 constraints);
		} 
		catch (NamingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return searchResult;
	}
	
	/******************************************************************
	 * 
	 * Retrives a list of users and their attributes of specified branchCode 
	 * and stores that retrived data in a form of the list of attributes (attr)
	 * 
	 * @param branchCode
	 *****************************************************************/

	 public boolean isUserOfBranchInGroup(String userId, String branch, String group)
	 {
		 boolean retVal = false;
		 try 
			{     

			    String strSearch = String.format("(&(objectCategory=user)(department=%s)(sAMAccountName=%s)(memberOf=CN=%s,OU=BPM,DC=ibar,DC=int))", 
							    		 branch.trim(), 
							    		 userId.trim(), 
							    		 group.trim());
	            NamingEnumeration answer = searchLdap(strSearch);

	            if (answer.hasMoreElements())
	            	retVal = true;

	            answer.close();
	        } 
			catch (Exception ex) 
			{
	            ex.printStackTrace();
	        }
		 
		 return retVal;
	 }

}
