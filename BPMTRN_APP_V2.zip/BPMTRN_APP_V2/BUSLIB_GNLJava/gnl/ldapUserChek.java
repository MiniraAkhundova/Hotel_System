package gnl;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.print.DocFlavor.STRING;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.iba.bpm.CommonRoutines;


public class ldapUserChek {



	
	
	public static Boolean getUserStatus(String param){
		boolean status = false;
		LdapUtils ldapUtils = new LdapUtils();
		SearchControls constraints = new SearchControls(); 
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        NamingEnumeration answer= null;
        String user = CommonRoutines.getConfServicePropertyValue("LDAPBB", "user");
        String pass = CommonRoutines.getConfServicePropertyValue("LDAPBB", "password");
        String url = CommonRoutines.getConfServicePropertyValue("LDAPBB", "url");
        DirContext dirContext = null; 
        String a ="(&(objectCategory=user)(uid=" + param + "))";
//         "(&(objectCategory=user)(|(employeeID="+finCode+"*)))";
        String b = "DC=banking,DC=int";
        SearchControls controls = new SearchControls();
        controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        controls.setCountLimit(Integer.parseInt( "5000"));
        controls.setTimeLimit(5000);
        
        try {
        	
        	dirContext = ldapUtils.getLdapContext(user, pass, url);
			answer = dirContext.search( b, a, controls);
			
			
			 while (answer.hasMoreElements()) {
	                Attributes attrs = ((SearchResult) answer.next()).getAttributes(); 
	               String uID = null;
	                 uID =  attrs.get("uID").toString();
	                 
	                 if(!uID.equals(null) ){
	                	 status = true;
	                 }
	                	 
	             
	            }
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			status = false;
			e.printStackTrace();
			return status;
			
		}finally{
			if(dirContext!= null){
				ldapUtils.closeLdapContext(dirContext);
			}
//				ldapUtils.closeLdapContext(dirContext);
			
		}
		
		return status;
	} 
	

	

}
